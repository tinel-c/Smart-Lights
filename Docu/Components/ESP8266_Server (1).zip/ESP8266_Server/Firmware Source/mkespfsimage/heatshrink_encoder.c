//Stupid wraparound include to make sure object file doesn't end up in heatshrink dir

#include "../lib/heatshrink/heatshrink_encoder.c"
