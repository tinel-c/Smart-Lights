void ICACHE_FLASH_ATTR ioLed(int ena);
int ICACHE_FLASH_ATTR ioButton();
void ioInit(void);
