
//Define this if you want to be able to use Heatshrink-compressed espfs images.
#define EFS_HEATSHRINK

//Pos of esp fs in flash
#define ESPFS_POS 0x12000
