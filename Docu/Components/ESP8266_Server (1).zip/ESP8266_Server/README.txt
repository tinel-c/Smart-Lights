A sample projects for either OLIMEXINO-32U4 or OLIMEXINO-328 connected to MOD-WIFI-ESP8266 or MOD-WIFI-ESP8266-DEV based on project of Jeroen Domburg.
It gives you the opportunity to turn on/off the LED on the host board and scan the state of the button.

In the projects a slight differences are required since OLIMEXINO-32U4 and OLIMEXINO-328 have different hardware (CPU, LED, Button and other peripheral). For example - the user button on OLIMEXINO-32U4 is not on one of the digital pins and should be accessed via DDR and PIN registers. Also OLIMEXINO-32U4 has pin which enables/disables UEXT power which is pin 8. It enables it when it is low output.

In order to work you must do several things:
1) Update the firmware of the ESP8266 module
	In "Firmware prebuilt" directory you can find the prebuilt *.bin files and the webpage that must be uploaded. They can be uploaded to the board using FLASH_DOWNLOAD_TOOL software and UART lines (RX and TX). IMPORTANT: YOU WOULD NEED A LEVEL SHIFTER TO CONNECT THE UART LINES TO A PERSONAL COMPUTER - SERIAL-CABLE OR MAX232. ELSE THE CONNECTION WILL NOT BE A SUCCESSFULL. The webpage must have offset 0x12000, and the other two files the same (offset) as the name of the file.
	To enter firmware upload mode you must connect GPIO0 to ground before start.
	If you use MOD-ESP8266 you can do this by switch the SMD jumper position to 0. After uploading you must return this jumper to its original position.
	If you use MOD-ESP8266-DEV you can either:
	1.1) make short between GPIO0 and ground using jumper wire. After uploading is complete remove the wire.
	1.2) if you attached it to ESP8266-EVB board just press the button when you power-up. After uploading is complete reset the board.

2) Upload the respective Arduino project to the host board (Olimexino_32U4_ESP8266 or Olimexino_328_ESP8266 depending on your board)
	NOTE!!! Keep in mind that if you use the ESP8266-EVB board you must uncomment the first line (//#define  ESP8266_EVB). This is necessary since it is a host board and RX and TX are crossed.

3) Connect the host board (OLIMEXINO-32U4/328) to the ESP module (no matter which one) using the UEXT.

4) With wireless device connect to the network that ESP module has created. By default the SSID of the wireless network should be something like ESP_XXXXXX (where the XXXXXX will be the last 6 hexadecimal digits from the MAC address of the module).


When you are connected to the network go to 192.168.4.1
There you will see a welcome index page showing how many times the page has been accessed and also few links. LED and button links are also there.
When you go to the LED page you can change the state of the LED on the host board (OLIMEXINO-32U4/328) by clicking the buttons '1' and '0'.
If you want to read the state of the button on the board go to button page and "Update button status".


Author:		Stanimir Petev
Company:	Olimex
Date:		2015/01/27