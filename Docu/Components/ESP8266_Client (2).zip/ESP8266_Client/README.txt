Sample demo projects for Olimexino-32U4 and MOD-WIFI-ESP8266 showing variety of features as a client using AT commands. In all of these programs PIC-WEB is used as a server (default IP address is 192.168.0.130).

By default this is the firmware of a newly purchased MOD-WIFI-ESP8266 or MOD-WIFI-ESP8266-DEV board. If you changed it then first make sure to update the firmware of the ESP8266 module again. In "Firmware prebuilt" directory you can find the prebuilt *.bin files and the webpage that must be uploaded. They can be uploaded to the board using FLASH_DOWNLOAD_TOOL software and UART lines (RX and TX). IMPORTANT: YOU WOULD NEED A LEVEL SHIFTER TO CONNECT THE UART LINES TO A PERSONAL COMPUTER - SERIAL-CABLE OR MAX232. ELSE THE CONNECTION WILL NOT BE A SUCCESSFULL. To enter firmware upload mode you must connect GPIO0 to ground before start. If you use MOD-ESP8266 you can do this by switch the SMD jumper position to 0. After uploading you must return this jumper to its original position. If you use MOD-ESP8266-DEV you can either:
	
	- make short between GPIO0 and ground using jumper wire. After uploading is complete remove the wire
	or
	- if you attached it to ESP8266-EVB board just press the button when you power-up. After uploading is complete reset the board

AT commands are sent to the ESP module via Olimexino-32U4 hardware UART (Serial1). The results are shown using the software UART (Serial) and can be observed on the Serial monitor embedded to the Arduino IDE.

In order to work you must have firmware that supports AT commands uploaded to the ESP8266 module. These demos are tested with firmware revision <00160901>.

Olimexino_32U4_Toggle_Server_LED:
Upon a button push on the host board (OLIMEXINO-32U4) the LED on the server (PIC-WEB) is toggled.

Olimexino_32U4_Get_Server_Peripheral_Data:
Upon a button push on the host board (OLIMEXINO-32U4) on the console are printed the values of the peripherals of the server (PIC-WEB) - LED state; button state; Temperature; Potentiometer value. To terminate data transfer push the button again. LEDs indicates whether transfer is active (green LED) or not (yellow LED).

Olimexino_32U4_Get_Server_Page:
On button push on the host board (OLIMEXINO-32U4) on the console is printed HTML code of the index page from the server (PIC-WEB).

Olimexino_32U4_MOD_WiFi:
All of the above programs in one. Using software UART a menu will be shown where you can choose which of these you want to do.


Author:		Stanimir Petev
Company:	Olimex
Date:		2015/01/27